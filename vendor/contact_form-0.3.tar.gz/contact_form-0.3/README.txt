================================
Generic contact forms for Django
================================


This is an application which provides generic, extensible contact-form
functionality for use in Django_ projects; for installation
instructions, see the file ``INSTALL.txt`` in this directory, and for
documentation see the files in the ``docs/`` directory.

The latest versions of these documents can always be viewed on the
Google Code project web site for this application, which is located at
http://code.google.com/p/django-contact/form/.

.. _Django: http://www.djangoproject.com/